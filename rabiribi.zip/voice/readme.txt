You can edit these wav to anything you want (e.g. Character Voices)

你可以任意修改這些wav檔案　(如改成人物配音)