Added Launch Option -moderina, which make the game load "save/modify/erina_a.png" instead of in game package's "player_a.png"
Added Launch Option -modribbon, which make the game load "save/modify/ribbon_a.png" instead of in game package's "fairy_a.png"

*WARNING : if save/modify/*.png don't exist Erina or Ribbon will become invisible!